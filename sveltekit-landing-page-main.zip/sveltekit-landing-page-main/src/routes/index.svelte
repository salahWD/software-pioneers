<script>
  import LandingPage from '$lib/component/landing/LandingPage.svelte';
</script>

<LandingPage />

<!-- <h1 class="">Welcome to SvelteKit</h1>
<p>Visit <a class="text-blue-600 underline" href="https://kit.svelte.dev">kit.svelte.dev</a> to read the documentation</p> -->
